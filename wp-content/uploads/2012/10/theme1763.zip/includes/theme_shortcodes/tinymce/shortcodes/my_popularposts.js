frameworkShortcodeAtts={
	attributes:[
			{
				label:"How many posts to show?",
				id:"num",
				help:"This is how many popular posts will be displayed."
			}
	],
	defaultContent:"",
	shortcode:"popular_posts",
	shortcodeType: "text-replace"
};
